package com.example.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private var no1 : TextView? = null
    private var no2 : TextView? = null
    private var answer: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);


        val buttonAdd = findViewById<Button>(R.id.btnAddi);
        val buttonSub = findViewById<Button>(R.id.btnSubt);
        val buttonMul = findViewById<Button>(R.id.btnMult);
        val buttonDiv = findViewById<Button>(R.id.btnDivi);
        no1  = findViewById(R.id.numb1);
        no2  = findViewById(R.id.numb2);
         answer = findViewById(R.id.answer);

        buttonAdd.setOnClickListener {
            add()
        }
        buttonSub.setOnClickListener {
            sub()
        }
        buttonMul.setOnClickListener {
            mul()
        }
        buttonDiv.setOnClickListener {
            div()
        }
    }
    private fun add(){
        if (isNotEmpty()) {
        var input1 = no1?.text.toString().trim().toBigDecimal()
            var input2 = no2?.text.toString().trim().toBigDecimal()
            var result = input1.add(input2)
            answer?.text ="$input1 + $input2 = $result"
        }
    }

    private fun isNotEmpty(): Boolean {
        var b = true
        if ( no1?.text.toString().trim().isEmpty()){
           answer?.error ="Required"
            b = false
        }
        if ( no2?.text.toString().trim().isEmpty()){
            answer?.error ="Required"
            b = false
        }
        return b
    }

    private fun sub(){
        if (isNotEmpty()) {
            var input1 = no1?.text.toString().trim().toBigDecimal()
            var input2 = no2?.text.toString().trim().toBigDecimal()
            var result = input1.subtract(input2)
            answer?.text ="$input1 - $input2 = $result"
        }
    }
    private fun mul(){
        if (isNotEmpty()) {
            var input1 = no1?.text.toString().trim().toBigDecimal()
            var input2 = no2?.text.toString().trim().toBigDecimal()
            var result = input1.multiply(input2)
            answer?.text ="$input1 x $input2 = $result"
        }
    }
    private fun div(){
        if (isNotEmpty()) {
            var input1 = no1?.text.toString().trim().toBigDecimal()
            var input2 = no2?.text.toString().trim().toBigDecimal()
            var result = input1.divide(input2,2,RoundingMode.HALF_UP)
            answer?.text ="$input1 / $input2 = $result"
        }
    }


}






